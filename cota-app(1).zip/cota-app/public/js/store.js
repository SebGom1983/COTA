import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getFirestore,
  collection,
  doc,
  addDoc,
  setDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  onSnapshot,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);

// ---------- Entrenos (running manual + gym) ----------

export function addWorkout(uid, workout) {
  return addDoc(collection(db, `users/${uid}/workouts`), {
    ...workout,
    createdAt: new Date().toISOString(),
  });
}

export function deleteWorkout(uid, id) {
  return deleteDoc(doc(db, `users/${uid}/workouts/${id}`));
}

export function watchWorkouts(uid, callback, max = 100) {
  const q = query(collection(db, `users/${uid}/workouts`), orderBy("date", "desc"), limit(max));
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}

// ---------- Métricas físicas (peso, medidas, fotos) ----------

export async function addMetric(uid, metric, photoFile) {
  let photoURL = null;
  if (photoFile) {
    const fileRef = ref(storage, `users/${uid}/metrics/${Date.now()}_${photoFile.name}`);
    await uploadBytes(fileRef, photoFile);
    photoURL = await getDownloadURL(fileRef);
  }
  return addDoc(collection(db, `users/${uid}/metrics`), {
    ...metric,
    photoURL,
    createdAt: new Date().toISOString(),
  });
}

export function watchMetrics(uid, callback, max = 60) {
  const q = query(collection(db, `users/${uid}/metrics`), orderBy("date", "desc"), limit(max));
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}

// ---------- Feed comunidad (opcional, público) ----------

export function shareToFeed(uid, displayName, workout) {
  return addDoc(collection(db, "feed"), {
    uid,
    displayName,
    summary: workout,
    createdAt: new Date().toISOString(),
  });
}

export function watchFeed(callback, max = 30) {
  const q = query(collection(db, "feed"), orderBy("createdAt", "desc"), limit(max));
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}
