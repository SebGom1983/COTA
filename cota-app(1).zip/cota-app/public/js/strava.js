import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-functions.js";
import { doc, getDoc, getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { app } from "./store.js";
import { STRAVA_CLIENT_ID, STRAVA_REDIRECT_URI } from "./firebase-config.js";

const functions = getFunctions(app);

export function startStravaConnect() {
  const url = new URL("https://www.strava.com/oauth/authorize");
  url.searchParams.set("client_id", STRAVA_CLIENT_ID);
  url.searchParams.set("redirect_uri", STRAVA_REDIRECT_URI);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("approval_prompt", "auto");
  url.searchParams.set("scope", "read,activity:read_all");
  window.location.href = url.toString();
}

// Llamar al cargar la app: revisa si venimos de vuelta de Strava con ?code=...
export async function handleStravaCallback() {
  const params = new URLSearchParams(window.location.search);
  const code = params.get("code");
  if (!code) return null;

  // limpiar la URL para no reprocesar el code si el usuario refresca
  window.history.replaceState({}, document.title, window.location.pathname);

  const exchangeStravaCode = httpsCallable(functions, "exchangeStravaCode");
  const result = await exchangeStravaCode({ code });
  return result.data; // { connected: true, synced: N }
}

export async function isStravaConnected(uid) {
  const db = getFirestore(app);
  const snap = await getDoc(doc(db, `users/${uid}/private/strava`));
  return snap.exists();
}

export async function syncStravaNow() {
  const syncNow = httpsCallable(functions, "syncNow");
  const result = await syncNow();
  return result.data; // { uid, synced: N }
}
