# Cota 🏔️

App de entrenamiento: running + gym + métricas físicas, con sync automático a Strava.
Frontend estático (GitHub Pages) + Firebase (Auth, Firestore, Storage, Cloud Functions).

## 0. Qué necesitas

- Cuenta de Google (para Firebase)
- Cuenta de Strava
- Node.js instalado en tu compu
- `npm install -g firebase-tools`

---

## 1. Crear el proyecto de Firebase

1. Ve a https://console.firebase.google.com → **Crear proyecto** → nómbralo `cota-app` (o el nombre que quieras).
2. En el proyecto, activa:
   - **Authentication** → Sign-in method → habilita **Google**.
   - **Firestore Database** → Crear base de datos (modo producción, la región más cercana, ej. `southamerica-east1`).
   - **Storage** → Comenzar (mismo bucket por defecto).
3. **Upgrade a plan Blaze** (Configuración del proyecto → Uso y facturación). Necesario para Cloud Functions.
   El free tier de Blaze es muy generoso — para uso personal/grupo de amigos no vas a pagar nada, pero sí requiere tarjeta asociada.
4. En **Configuración del proyecto → Tus apps → Web (`</>`)**, registra una app y copia el objeto `firebaseConfig`.
5. Pega esos valores en `public/js/firebase-config.js`.

---

## 2. Crear la app de Strava

1. Ve a https://www.strava.com/settings/api y crea una app.
2. En **"Authorization Callback Domain"** pon el dominio de GitHub Pages SIN `https://` ni ruta, ej: `tuusuario.github.io`.
3. Copia el **Client ID** y pégalo en `public/js/firebase-config.js` (`STRAVA_CLIENT_ID`).
4. Copia el **Client Secret** — este NO va en el frontend, va como *secret* de Cloud Functions (paso 3).
5. Actualiza `STRAVA_REDIRECT_URI` en `firebase-config.js` con la URL final donde vas a publicar la app
   (ej: `https://tuusuario.github.io/cota-app/`).

---

## 3. Configurar y desplegar las Cloud Functions

```bash
cd cota-app
firebase login
firebase use --add          # selecciona tu proyecto de Firebase

# Guardar el client secret de Strava de forma segura (NUNCA en el código)
firebase functions:secrets:set STRAVA_CLIENT_ID
firebase functions:secrets:set STRAVA_CLIENT_SECRET

cd functions
npm install
cd ..

firebase deploy --only functions,firestore:rules,storage:rules
```

Esto despliega:
- `exchangeStravaCode` — intercambia el código OAuth por tokens (se llama automáticamente cuando conectas Strava desde la app).
- `syncNow` — sync manual desde el botón "Sincronizar ahora".
- `scheduledStravaSync` — corre sola cada 3 horas y sincroniza a todos los usuarios conectados.

---

## 4. Publicar el frontend en GitHub Pages

```bash
cd cota-app
git init
git add .
git commit -m "Cota v1"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/cota-app.git
git push -u origin main
```

Luego, en GitHub → Settings → Pages → Source: rama `main`, carpeta `/public` (o mueve el contenido de `public/` a la raíz si prefieres carpeta `/root`).

⚠️ Importante: la URL final debe coincidir EXACTO con `STRAVA_REDIRECT_URI` en `firebase-config.js` y con el
"Authorization Callback Domain" de tu app de Strava.

---

## 5. Probar

1. Abre tu URL de GitHub Pages → **Entrar con Google**.
2. Ve a **Panel** → **Conectar con Strava** → autoriza.
3. Deberías ver tus carreras recientes importadas automáticamente.
4. Registra una sesión de gym o una métrica física manualmente para probar esos formularios.

---

## Estructura del proyecto

```
cota-app/
├── public/              ← esto es lo que se publica en GitHub Pages
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── firebase-config.js   ← TUS credenciales van aquí
│       ├── auth.js
│       ├── store.js
│       ├── strava.js
│       ├── charts.js
│       └── app.js
├── functions/            ← Cloud Functions (backend, nunca se publica en GitHub Pages)
│   └── index.js
├── firestore.rules
├── storage.rules
└── firebase.json
```

## Modelo de datos (Firestore)

- `profiles/{uid}` — nombre y foto públicos
- `users/{uid}/private/strava` — tokens de Strava (privado, solo el dueño y las Functions lo leen)
- `users/{uid}/workouts/{id}` — carreras (manuales o de Strava) y sesiones de gym
- `users/{uid}/metrics/{id}` — peso, % grasa, fotos de progreso
- `feed/{id}` — posts públicos opcionales para la pestaña Comunidad

## Coach (nuevo)

Pestaña "Coach" con lógica basada en ciencia del deporte (no IA — son reglas y fórmulas verificables):

- **Predictor de tiempos** (fórmula de Riegel) para 5K/10K/15K/21.1K/42.2K a partir de tu mejor rendimiento reciente.
- **Zonas de running** por ritmo, derivadas de tu ritmo umbral estimado (proxy: tu predicción de 10K).
- **Zonas de ciclismo** por potencia (si tu Garmin/Strava reporta vatios) o por FC como respaldo.
- **Carga combinada (ACWR)**: ratio agudo:crónico (7 días vs 28 días) sumando running + ciclismo + gym, con zonas de riesgo (baja carga / óptima / precaución / riesgo alto). Usa el `relative_effort` (suffer score) de Strava cuando existe.
- **Feedback post-entreno**: compara tu última sesión contra tu propio promedio reciente en ese mismo tipo de disciplina.
- **Sugerencia del próximo entreno**: árbol de decisión simple (¿vienes de una sesión dura? ¿estás en semana de taper? ¿llevas días sin cross-training?).
- **PRs automáticos** por distancia (5K/10K/15K/21.1K).

El sync de Strava ahora también trae **ciclismo** (Ride/VirtualRide/Gravel/MTB) y sesiones de **gym** si las registras como "WeightTraining" en Strava — no solo running.

⚠️ Las fechas de tus carreras (`RACES` en `public/js/coach.js`) están hardcodeadas con lo que tengo de tu plan actual — actualízalas ahí si cambian.

## Ideas para siguientes iteraciones

- Botón "Compartir en el feed" desde una tarjeta de carrera (ahora mismo el feed existe en el modelo de datos pero falta conectarlo a un botón en la UI).
- Metas / PRs automáticos (ej. detectar tu mejor 21K y mostrarlo destacado).
- Webhook de Strava en vez de sync cada 3h, para que sea casi instantáneo.
- Comparar tu progreso semanal con tu plan de entrenamiento.
