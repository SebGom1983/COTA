const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();
const db = admin.firestore();

const STRAVA_CLIENT_ID = defineSecret("STRAVA_CLIENT_ID");
const STRAVA_CLIENT_SECRET = defineSecret("STRAVA_CLIENT_SECRET");

// ---------- helpers ----------

async function refreshAccessToken(uid, stravaData, clientId, clientSecret) {
  const res = await fetch("https://www.strava.com/oauth/token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: "refresh_token",
      refresh_token: stravaData.refreshToken,
    }),
  });
  const data = await res.json();
  if (!data.access_token) {
    throw new Error("No se pudo refrescar el token de Strava: " + JSON.stringify(data));
  }
  const updated = {
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    expiresAt: data.expires_at, // unix seconds
  };
  await db.doc(`users/${uid}/private/strava`).set(updated, { merge: true });
  return updated;
}

async function getValidToken(uid, stravaData, clientId, clientSecret) {
  const now = Math.floor(Date.now() / 1000);
  if (stravaData.expiresAt && stravaData.expiresAt > now + 60) {
    return stravaData;
  }
  return refreshAccessToken(uid, stravaData, clientId, clientSecret);
}

const RUN_TYPES = ["Run", "TrailRun"];
const RIDE_TYPES = ["Ride", "VirtualRide", "GravelRide", "MountainBikeRide"];
const GYM_TYPES = ["WeightTraining", "Workout", "Crossfit"];

function disciplineOf(stravaType) {
  if (RUN_TYPES.includes(stravaType)) return "run";
  if (RIDE_TYPES.includes(stravaType)) return "ride";
  if (GYM_TYPES.includes(stravaType)) return "gym";
  return null;
}

function mapStravaActivity(a) {
  const type = disciplineOf(a.sport_type || a.type);
  return {
    source: "strava",
    stravaId: a.id,
    type,
    name: a.name,
    date: a.start_date, // ISO string
    distanceKm: a.distance ? +(a.distance / 1000).toFixed(2) : null,
    durationSec: a.moving_time,
    elevationGainM: a.total_elevation_gain || 0,
    avgPaceMinKm:
      type === "run" && a.moving_time && a.distance
        ? +((a.moving_time / 60) / (a.distance / 1000)).toFixed(2)
        : null,
    avgSpeedKmh: type === "ride" && a.average_speed ? +(a.average_speed * 3.6).toFixed(1) : null,
    avgWatts: a.average_watts || null,
    avgHeartRate: a.average_heartrate || null,
    relativeEffort: a.suffer_score || null,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  };
}

async function syncUserActivities(uid, clientId, clientSecret) {
  const privRef = db.doc(`users/${uid}/private/strava`);
  const snap = await privRef.get();
  if (!snap.exists) return { uid, synced: 0 };
  const stravaData = snap.data();

  const token = await getValidToken(uid, stravaData, clientId, clientSecret);

  const after = stravaData.lastSyncEpoch || Math.floor(Date.now() / 1000) - 60 * 60 * 24 * 90; // primeras vez: últimos 90 días
  const res = await fetch(
    `https://www.strava.com/api/v3/athlete/activities?after=${after}&per_page=100`,
    { headers: { Authorization: `Bearer ${token.accessToken}` } }
  );
  const activities = await res.json();
  if (!Array.isArray(activities)) {
    throw new Error("Respuesta inesperada de Strava: " + JSON.stringify(activities));
  }

  const relevant = activities.filter((a) => disciplineOf(a.sport_type || a.type) !== null);
  const batch = db.batch();
  let count = 0;
  for (const a of relevant) {
    const ref = db.doc(`users/${uid}/workouts/strava_${a.id}`);
    batch.set(ref, mapStravaActivity(a), { merge: true });
    count++;
  }
  await batch.commit();

  await privRef.set(
    { lastSyncEpoch: Math.floor(Date.now() / 1000) },
    { merge: true }
  );

  return { uid, synced: count };
}

// ---------- callable: intercambiar el "code" que devuelve Strava por tokens ----------

exports.exchangeStravaCode = onCall(
  { secrets: [STRAVA_CLIENT_ID, STRAVA_CLIENT_SECRET] },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
    const { code } = request.data;
    if (!code) throw new HttpsError("invalid-argument", "Falta el código de Strava.");

    const res = await fetch("https://www.strava.com/oauth/token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client_id: STRAVA_CLIENT_ID.value(),
        client_secret: STRAVA_CLIENT_SECRET.value(),
        code,
        grant_type: "authorization_code",
      }),
    });
    const data = await res.json();
    if (!data.access_token) {
      throw new HttpsError("internal", "Strava rechazó el código: " + JSON.stringify(data));
    }

    await db.doc(`users/${request.auth.uid}/private/strava`).set(
      {
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
        expiresAt: data.expires_at,
        athleteId: data.athlete ? data.athlete.id : null,
        connectedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    // primer sync inmediato
    const result = await syncUserActivities(
      request.auth.uid,
      STRAVA_CLIENT_ID.value(),
      STRAVA_CLIENT_SECRET.value()
    );

    return { connected: true, synced: result.synced };
  }
);

// ---------- callable: el usuario puede pedir "sincronizar ahora" desde la app ----------

exports.syncNow = onCall(
  { secrets: [STRAVA_CLIENT_ID, STRAVA_CLIENT_SECRET] },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
    const result = await syncUserActivities(
      request.auth.uid,
      STRAVA_CLIENT_ID.value(),
      STRAVA_CLIENT_SECRET.value()
    );
    return result;
  }
);

// ---------- scheduled: sincroniza a todos los usuarios conectados cada 3 horas ----------

exports.scheduledStravaSync = onSchedule(
  { schedule: "every 3 hours", secrets: [STRAVA_CLIENT_ID, STRAVA_CLIENT_SECRET] },
  async () => {
    const allUsers = await db.collection("users").listDocuments();
    const clientId = STRAVA_CLIENT_ID.value();
    const clientSecret = STRAVA_CLIENT_SECRET.value();

    for (const userDoc of allUsers) {
      try {
        await syncUserActivities(userDoc.id, clientId, clientSecret);
      } catch (err) {
        console.error(`Error sincronizando ${userDoc.id}:`, err.message);
      }
    }
    return null;
  }
);
